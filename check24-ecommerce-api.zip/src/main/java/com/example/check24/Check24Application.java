package com.example.check24;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Check24Application {

	public static void main(String[] args) {
		SpringApplication.run(Check24Application.class, args);
	}

}
